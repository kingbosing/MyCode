/**
 * Created by Administrator on 2016/8/8 0008.
 */
(function () {

    var img = document.getElementsByTagName("img");
    var widthPercent = 100;
    var i = 0;

    function change() {
        var change1 = setInterval(function () {
            widthPercent -= 10;
            img[i].style.width = widthPercent + "%";
            if (widthPercent == 0) {
                img[i].style.display = "none";
                clearInterval(change1);
                i++;
                i = i % 2;
                var change2 = setInterval(function () {
                    widthPercent += 10;
                    img[i].style.display = "block";
                    img[i].style.width = widthPercent + "%";
                    if (widthPercent == 100) {
                        clearInterval(change2);
                    }
                }, 50)
            }
        }, 50)
    }


    img[0].addEventListener("click", change);
    img[1].addEventListener("click", change);

})();