/**
 * Created by Administrator on 2016/8/12 0012.
 */

(function () {

    var div = document.getElementById("div");

    div.onmousedown = function (event) {
        var x = event.pageX;
        var y = event.pageY;
        var divx = div.offsetLeft;
        var divy = div.offsetTop
        div.onmousemove = function (event) {
            div.style.left = divx + event.pageX - x + "px";
            div.style.top = divy + event.pageY - y + "px";
        }
    }

    div.onmouseup = function () {
        div.onmousemove = null;
    }

})();