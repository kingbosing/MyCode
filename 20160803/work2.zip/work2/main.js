/**
 * Created by Administrator on 2016/8/4 0004.
 */


var id1 = {name: "zhangsan", score: 70};
var id2 = {name: "lisi", score: 60};
var id3 = {name: "wangwu", score: 80};
var id4 = {name: "zhaoliu", score: 50};
var all = [id1, id2, id3, id4];


var tab = document.createElement("table");
document.body.appendChild(tab);
tab.border=2;
for (i = 0; i < 5; i++) {
    var tr = document.createElement("tr");
    tab.appendChild(tr);
    for (j = 0; j < 2; j++) {
        var td = document.createElement("td");
        tr.appendChild(td);
        td.className = i+""+j;
        if(i==0 && j==1){
            var a = document.createElement("a");
            td.appendChild(a);
            a.href = "#";
            a.innerHTML = "分数";
        }
    }
}




function sort(arr) {
    for (var i = arr.length; i > 1; i--) {
        for (var j = 0; j < i - 1; j++) {
            if (arr[j].score > arr[j + 1].score) {
                var k = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = k;
            }
        }
    }
}



all.reverse()



    for(i=1;i<4;i++) {
        for(j=0;j<2;j++) {
            var Na = i+""+j;
            var ss = document.getElementsByClassName(Na);
            ss[0].innerHTML = all[i].score;
            if (j==0){ss[0].innerHTML = all[i].name;}
        }
    }




//
// function PrintArr() {
//     for (i=0;i<4;i++) {
//         for(j=0;j<2;j++) {
//             var td = document.getElementsByClassName("00");
//             td.innerHTML = "hi";
//         }
//     }
// }
//
// PrintArr();


