/**
 * Created by Administrator on 2016/8/9 0009.
 */
(function () {

    var container = document.getElementById("container");
    var Html = document.getElementById("Html");
    var Css = document.getElementById("Css");
    var JS = document.getElementById("JS");

    container.oncontextmenu = function () {
        return false;
    }

    function CustomMenu(event) {
        var event = event || window.event;
        var Menu = document.getElementById("menu");
        Menu.oncontextmenu = function () {
            return false;
        }

        function CustomMenuPosition(Menu) {
            Menu.style.left = event.pageX + "px";
            if (event.pageX >= 206) {
                Menu.style.left = "206px";
            }
            Menu.style.top = event.pageY + "px";
            if (event.pageY >= 214) {
                Menu.style.top = "214px";
            }
        }

        function ShowMenu(Menu) {
            Menu.style.display = "block";
            CustomMenuPosition(Menu);
        }

        function HidMenu(Menu) {
            Menu.style.display = "none";
        }


        if (event.button == 2) {
            ShowMenu(Menu);
        }
        else {
            HidMenu(Menu);
        }

        Html.onclick =  function () {
            HidMenu(Menu);
            alert("想学HTML吗？");
        }

        Css.onclick =  function () {
            HidMenu(Menu);
            alert("CSS是用来修改样式的！");
        }

        JS.onclick = function () {
            HidMenu(Menu);
            alert("JS可是很强的！");
        }

    }

    container.onmousedown = CustomMenu;


})();